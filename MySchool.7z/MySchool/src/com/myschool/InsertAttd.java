package com.myschool;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class InsertAttd
 */
@WebServlet("/InsertAttd")
public class InsertAttd extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertAttd() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String id=request.getParameter("sid");
		System.out.println("id"+id);
		String clas=request.getParameter("clas");
		System.out.println("clas"+clas);
		String dat=request.getParameter("date");
		System.out.println(dat);
		String month=null;
		//System.out.println(dat.charAt(5));
		month=dat.substring(5, 7);
		System.out.println(month);
		///month=dat.charAt(index)
		String act=request.getParameter("atd");
		System.out.println("came to insertattd");
		try
		{
			System.out.println("came to insertattd 2");
		Class.forName("com.mysql.jdbc.Driver");
    	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/myschool","root","root");
    	PreparedStatement pst=con.prepareStatement("insert into studentattendance values(?,?,?,?)");
    	pst.setString(1,id);
    	pst.setString(2,dat);
    	pst.setString(3,act);
    	pst.setString(4, month);
    	int i=pst.executeUpdate();
    	if(i>0)
    	{
    		System.out.println("came to insertattd 3");
    		HttpSession se=request.getSession();
    		se.setAttribute("id2", id);
    		se.setAttribute("dat2", dat);
    		se.setAttribute("clas", clas);
    		PreparedStatement pst2=con.prepareStatement("select * from studentattendance where id='"+id+"' and date='"+dat+"'");
    		ResultSet rs2=pst2.executeQuery();
    		if(rs2.next())
    		{
    			se.setAttribute("action",rs2.getString(3));
    		}
    		RequestDispatcher rd=request.getRequestDispatcher("home2.jsp");
    		rd.forward(request, response);
    	}
		}
		catch(Exception e)
		{
			out.println(e);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
